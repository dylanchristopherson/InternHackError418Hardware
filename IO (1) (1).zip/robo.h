#ifndef _MYLIB_H_
#define _MYLIB_H_

#define micPinA A0
#define micPinD A1
#define buzzPin A3
#define motorIn1 D0
#define motorIn2 D1
#define motorIn3 D2
#define motorIn4 D3
#define IR0 D7
#define IR1 D6
#define IR2 D5 
#define IR3 D4
#define servoPin1 A5
#define servoPin2 A4
#define LEDPin A2

int startUp();

int buzz(int dur);

int checkMic();

int getMicVal();

//not writting a function for Servo just use the built-in
//make servo object
//servoObject.attach(int pin)
//servoObject.moveServo( int position)
int goForwardL(int dur);

int goForwardR(int dur);

int goBackwardL(int dur);

int goBackwardR(int dur);

int checkIR(int IR);

int headlampOn();

int headlampOff();





#endif